<?
  require_once(__DIR__."/funs.php");
  ?>
  <div class="container">
    <div style='margin-top:90px'>
      <center>
      <b class='text-info'>成功登出,3秒後返回首頁</b>
      </center>
      <meta http-equiv="refresh" content="3;url=index.php" />
    </div>
  </div>
  
<?php
?>